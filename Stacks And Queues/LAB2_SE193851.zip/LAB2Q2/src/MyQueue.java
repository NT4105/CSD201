public class MyQueue {
    private Node head, tail;

    public MyQueue() {
        head = tail = null;
    }

    public void enqueue(int x) {
        Node node = new Node(x);
        if (isEmpty()) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
    }

    public int dequeue() throws Exception {
        if (isEmpty())
            throw new Exception("Queue is empty");
        int x = head.info;
        head = head.next;
        if (head == null)
            tail = null;
        return x;
    }

    public int first() throws Exception {
        if (isEmpty())
            throw new Exception("Queue is empty");
        return head.info;
    }

    public void clear() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void traverse() {
        Node current = head;
        while (current != null) {
            System.out.print(current.info + " ");
            current = current.next;
        }
        System.out.println();
    }

    public String decimalToBinary(double decimal) {
        // Implementation for decimal to binary conversion
        return Double.toString(decimal); // Placeholder implementation
    }
}
