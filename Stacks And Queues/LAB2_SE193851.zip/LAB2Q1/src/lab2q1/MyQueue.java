package lab2q1;

public class MyQueue {

}
