package lab2q4;

public class Node {
    char info;
    Node next;

    public Node(char info) {
        this.info = info;
        this.next = null;
    }
}
