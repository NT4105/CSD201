package lab2q3;

public class Node {
    String info;
    Node next;

    public Node(String info) {
        this.info = info;
        this.next = null;
    }
}
