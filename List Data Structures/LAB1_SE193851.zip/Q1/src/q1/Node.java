package q1;

public class Node {
    int info;
    Node next;

    public Node() {
    }

    Node(int d) {
        info = d;
        next = null;
    }
}
