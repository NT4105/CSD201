package q2;

class Node {
    String info;
    Node next;

    public Node() {
    }

    public Node(String info) {
        this.info = info;
        this.next = null;
    }
}
