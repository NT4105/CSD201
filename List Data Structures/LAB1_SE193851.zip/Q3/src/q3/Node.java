package q3;

public class Node {
    int info;
    Node head;
    Node tail;

    public Node(int info) {
        this.info = info;
        this.head = null;
        this.tail = null;
    }
}
